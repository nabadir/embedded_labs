
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>

#include "WiimoteBtns.h"


using namespace std;


int main()
{
	WiimoteBtns myWii;
	myWii.Listen();
	return 0;
}


