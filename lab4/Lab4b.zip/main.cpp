
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>

#include "WiimoteAccel.h"


using namespace std;


int main()
{
	WiimoteAccel myWii;
	myWii.Listen();
	return 0;
}


